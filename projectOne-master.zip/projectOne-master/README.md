# Project One
## Personal Page

### The Basics
By this point, this should be fairly simple for you to complete. 

Create a _single page_ personal site. 

#### Requirements
- Personal Image
- "About Me" Description
- Tell me about your goals and aspirations. 
- The cover of your favorite book, linked to it's Amazon page. Provide a description of why its your favorite book. 
- Top 3 favorite meals with an image and brief description for each. 
- Linked stylesheet with styles that customize the page to be more "you".
- Proper folder structure
- No image width beyond 800px.
- Forked repository of this repository on personal Github account.

#### Grading
- Overall quality of work
- Application of coding techniques
- Fulfilment of aforementioned requirements

#### Submission
In order to submit this project, you'll need to send me a link to your Github repository by the due date listed below. The aforementioned requirements will need to be committed prior to submission.

#### Due Date
Monday, October 10th @ 5pm.
